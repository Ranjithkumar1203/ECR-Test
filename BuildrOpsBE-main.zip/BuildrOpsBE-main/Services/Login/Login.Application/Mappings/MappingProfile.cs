﻿using AutoMapper;
using Login.Domain.Entities;

namespace Login.Application.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //CreateMap<Login, LoginVm>().ReverseMap();
        }
    }
}
