﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildrOps.Application.Features.Resource.Commands.UpdateResourceLibrary
{
   public class UpdateResourceLibraryResponse
    {
        public bool isSuccess { get; set; }
    }
}
