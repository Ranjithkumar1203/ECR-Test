﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildrOps.Application.Features.CompanyBasicRegistration.Command.ResendEmail
{
   public class ResendEmailResponse
    {
        public string message { get; set; }
        public bool IsSuccess { get; set; }
    }
}
