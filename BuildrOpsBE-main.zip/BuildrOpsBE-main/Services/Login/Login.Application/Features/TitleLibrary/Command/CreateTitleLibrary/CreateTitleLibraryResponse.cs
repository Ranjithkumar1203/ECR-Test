﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login.Application.Features.TitleLibrary.Command.CreateTitleLibrary
{
    public class CreateTitleLibraryResponse
    {
        public int TitleLibraryId { get; set; }
    }
}
