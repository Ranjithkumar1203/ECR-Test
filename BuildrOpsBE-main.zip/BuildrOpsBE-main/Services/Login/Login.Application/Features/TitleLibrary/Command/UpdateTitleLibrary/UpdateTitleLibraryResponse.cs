﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login.Application.Features.TitleLibrary.Command.UpdateTitleLibrary
{
    public class UpdateTitleLibraryResponse
    {
        public int Id { get; set; }
        public string Error { get; set; }
    }
}
