﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login.Application.Features.Holiday.Commands.DeleteHoliday
{
    public class DeleteHolidayResponse
    {
        public int Id { get; set; }
    }
}
