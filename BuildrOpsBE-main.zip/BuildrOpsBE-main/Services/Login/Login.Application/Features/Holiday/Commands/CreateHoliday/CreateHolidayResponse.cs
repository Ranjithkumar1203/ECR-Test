﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login.Application.Features.Holiday.Commands.CreateHoliday
{
    public class CreateHolidayResponse
    {
        public int HolidayId { get; set; }
    }
}
