﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login.Application.Features.Settings.Command.CreateSettingOption
{
    public class CreateSettingOptionResponse
    {
        public int SettingOptionId { get; set; }
    }
}
