﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildrOps.Application.Features.CompanyProfile.CompanyProjects.Commands.GetCompanyProject
{
   public class GetCompanyProjectResponse
    {
        public int Id { get; set; }
        public string ProjectName { get; set; }
    }
}
