﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildrOps.Application.Features.CompanyProfile.CompanyImages.Commands.GetCompanyImage
{
  public  class GetCompanyImageResponse
    {
        public int Id { get; set; }
        public string CompanyImage { get; set; }
    }
}
