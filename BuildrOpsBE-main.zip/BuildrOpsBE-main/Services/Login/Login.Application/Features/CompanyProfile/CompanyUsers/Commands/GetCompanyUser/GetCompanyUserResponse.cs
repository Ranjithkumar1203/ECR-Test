﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildrOps.Application.Features.CompanyProfile.CompanyUsers.Commands.GetCompanyUser
{
   public class GetCompanyUserResponse
    {
        public int Id { get; set; }
        public string UserName { get; set; }
    }
}
