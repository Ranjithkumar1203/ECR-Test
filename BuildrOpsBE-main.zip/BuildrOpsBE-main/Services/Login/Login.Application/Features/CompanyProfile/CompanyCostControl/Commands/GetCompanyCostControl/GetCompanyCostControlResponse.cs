﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildrOps.Application.Features.CompanyProfile.CompanyCostControl.Commands.GetCompanyCostControl
{
   public class GetCompanyCostControlResponse
    {
        public int Id { get; set; }

        public string CostControl { get; set; }
    }
}
