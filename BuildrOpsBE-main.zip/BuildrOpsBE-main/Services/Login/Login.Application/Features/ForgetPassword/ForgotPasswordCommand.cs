﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildrOps.Application.Features.ForgetPassword
{
    public class ForgotPasswordCommand
    {
        public string EmailIdUserName { get; set; }
    }
}
