﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildrOps.Application.Features.Department.Commands.CreateDepartment
{
    public class CreateDepartmentResponse
    {
        public int Id { get; set; }

    }
}
