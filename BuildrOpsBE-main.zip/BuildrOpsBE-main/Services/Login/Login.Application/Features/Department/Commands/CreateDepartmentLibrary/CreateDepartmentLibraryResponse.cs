﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildrOps.Application.Features.Department.Commands.CreateDepartmentLibrary
{
   public class CreateDepartmentLibraryResponse
    {
        public int Id { get; set; }
    }
}
