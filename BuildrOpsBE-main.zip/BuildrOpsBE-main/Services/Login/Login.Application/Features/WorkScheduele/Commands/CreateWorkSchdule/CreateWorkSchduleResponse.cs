﻿namespace Login.Application.Features.WorkScheduele.Commands.CreateWorkSchdule
{
    public class CreateWorkSchduleResponse
    {
        public int Id { get; set; }

    }
}