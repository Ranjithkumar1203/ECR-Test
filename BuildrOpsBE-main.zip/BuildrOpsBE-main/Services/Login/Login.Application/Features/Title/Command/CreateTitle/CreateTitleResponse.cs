﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login.Application.Features.Title.Command.CreateTitle
{
    public class CreateTitleResponse
    {
        public string msg { get; set; }
        public int TitleId { get; set; }
    }
}
