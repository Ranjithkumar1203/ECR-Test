﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login.Application.Features.Title.Command.UpdateTitle
{
    public class UpdateTitleResponse
    {
        public int Id { get; set; }
        public string Error { get; set; }
    }
}
